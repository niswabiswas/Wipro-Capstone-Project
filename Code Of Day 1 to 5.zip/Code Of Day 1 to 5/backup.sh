#!/bin/bash

source "$(pwd)/lib.sh"

read -p "Enter folder path to backup: " SRC
[ -z "$SRC" ] && SRC="$(pwd)"

if [ ! -d "$SRC" ]; then
  log "ERROR: $SRC is not a valid directory."
  exit 1
fi

BACKUP_DIR="$BASE/backups"
mkdir -p "$BACKUP_DIR"

FILE_NAME="backup-$(basename "$SRC")-$(date '+%Y%m%d_%H%M%S').tar.gz"

log "Starting backup of $SRC..."
if tar -czf "$BACKUP_DIR/$FILE_NAME" -C "$(dirname "$SRC")" "$(basename "$SRC")"; then
  log "Backup completed successfully: $BACKUP_DIR/$FILE_NAME"
else
  log "Backup failed!"
fi
